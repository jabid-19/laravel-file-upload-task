@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">

                        <a href="{{route('files.index')}}" class="btn btn-warning float-right">Back</a>
                    </div>

                    <div class="card-body">
                        {{Form::open(['route' => 'files.store', 'method' => 'POST', 'enctype'=>"multipart/form-data" ])}}
                        <div class="form-group">
                            <label for="exampleFormControlFile1">Upload File</label>
                            <input type="file"  name="file" for="file" class="form-control-file" id="file">
                            <span class="text-danger ">{{$errors->has('file') ? $errors->first('file') : ''}}</span>
                        </div>
                        <button type="submit" class="btn btn-primary">Upload</button>
                        {{Form::close()}}
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
