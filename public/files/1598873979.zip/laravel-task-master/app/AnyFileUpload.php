<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AnyFileUpload extends Model
{
    protected $fillable = [
        'file'
    ];
}
