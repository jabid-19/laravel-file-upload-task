<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\AnyFileUpload;
use Faker\Generator as Faker;

$factory->define(AnyFileUpload::class, function (Faker $faker) {
    return [
        //
    ];
});
